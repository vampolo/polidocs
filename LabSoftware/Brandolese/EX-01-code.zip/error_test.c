#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>


int main(int argc, char* argv[])
{
	int fd = open("inputfile.txt", O_RDONLY);
	if(fd == -1)
	{
		fprintf(stderr, "error opening file: Error number %d\n", errno);
		fprintf(stderr, "error opening file: %s\n", strerror(errno));
		perror("perror: error opening file");
		exit(1);
	}
}
