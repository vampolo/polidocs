#include <stdio.h>
#include <assert.h>

int somma(int a, int b, int* risultato)
{
	(*risultato) = (a + b);
	return (*risultato);
}

int main(int argc, char* argv[])
{
	int primo_operando, secondo_operando, risultato;
	/* Devono essere passati due operandi da linea di comando */
	assert(argc > 2);
	primo_operando = atoi(argv[1]);
	secondo_operando = atoi(argv[2]);
	assert(somma(primo_operando, secondo_operando, &risultato) != 10);
	printf("la somma � : %d\n", risultato);
	return 0;
}
