#include <stdio.h>
#include <assert.h>

int main(int argc, char* argv[])
{
	int parametro;
	/* Devo passare almeno un parametro da riga di comando */
	assert(argc > 1);
	parametro = atoi(argv[1]);
	assert(parametro != 0);
	printf("Hai passato il parametro %d.\n", parametro);
	return 0;
}
