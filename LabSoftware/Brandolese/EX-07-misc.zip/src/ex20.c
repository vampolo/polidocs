#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
	pid_t pid;
	int i, count;

	count = 1;
	for(i = 0; i <= 3; i++)
	{
		pid = fork();		
		if(pid == 0 && i / 2 * 2 == i)
		{	
			count++;		
			exit(0);
		}
	}

	printf("Process %d finished\n", getpid());
	printf("count is %d\n", count);

	return 0;
}

