#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

/* For debug purposes */
#define DEBUG

/* Get the fibonacci sequence up to the N-th element */
void get_fibonacci_sequence(int *fibonacci, int n);
/* Print sequence */
void print_sequence(int *fibonacci, int n);

int main(int argc, char *argv[])
{
	pid_t child;
	int left_pipe[2], right_pipe[2];
	int index, exit_flag, received_value, value_to_send, res, sem_id, N;
	/* Shared memory pointer */
	void *shared_mem_ptr;
	/* Shared memory id */
	int shared_mem_id;	
	/* Fibonacci sequence */
	int *fibonacci;

	exit_flag = 0;
	index = 0;
	received_value = 0;
	value_to_send = 0;

	/* Get the depth of the sequence, at least 3 in order to see something interesting */
	if(argc < 2)
	{
		fprintf(stderr, "Too few arguments\n");
		return -1;
	}
	N = atoi(argv[1]);
	if(N < 3)
	{	
		N = 3;
	}

	/* Get the fibonacci sequence up to the N-th element */
	fibonacci = (int *)malloc(sizeof(int) * N);
	get_fibonacci_sequence(fibonacci, N);

	#ifdef DEBUG
	print_sequence(fibonacci, N);
	#endif

	res = pipe(right_pipe);
	if(res == -1)
	{
		printf("Unable to create pipe\n");
		exit(EXIT_FAILURE);
	}

	/* Create a shared memory segment */
	shared_mem_id = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | S_IRUSR | S_IWUSR);
	if(shared_mem_id == -1)
	{
		fprintf(stderr, "Unable to allocate shared memory segment\n");
		return -1;
	}
	#ifdef DEBUG
	fprintf(stderr, "Shared memory segment allocated with identifier %d\n", shared_mem_id);
	#endif

	/* Attach and initialize value */
	shared_mem_ptr = shmat(shared_mem_id, NULL, 0);
	memset(shared_mem_ptr, 0, sizeof(int));
	#ifdef DEBUG
	fprintf(stderr, "Shared memory has been initialized\n");
	#endif

	child = fork();
	while(!exit_flag)
	{	
		#ifdef DEBUG
		/* Should never go inside IF branch */
		if(index > N)
		{
			fprintf(stderr, "---- Error! Program should never reach this point, "
				"at %d in '%s' with index=%d\n", 
				__LINE__, __FILE__, index);
			abort();
		}
		#endif

		/* Every child has to copy the right pipe (inherited from the parent) into the left pipe
		 * and close the corresponding write point; then, it has to create another pipe in the 
		 * right pipe (and forward it to the next child process) */
		if(child == 0)
		{	
			/* Attach memory segment */
			shared_mem_ptr = shmat(shared_mem_id, NULL, 0);
	
			/* Copy in left_pipe the right_pipe */	
			left_pipe[0] = right_pipe[0];	/* R */
			left_pipe[1] = right_pipe[1];	/* W */
			close(left_pipe[1]);			

			/* Read until EOF reached */
			while(read(left_pipe[0], &received_value, sizeof(int)) > 0) { }
				
			#ifdef DEBUG
			fprintf(stderr, "** Process %d received %d from parent %d\n", 
				getpid(), received_value, getppid());
			#endif
			
			/* Read index as modified by the parent */
			memcpy(&index, shared_mem_ptr, sizeof(int));
			#ifdef DEBUG
			fprintf(stderr, "** Process %d reads %d from shared memory\n", 
				getpid(), index);
			#endif

			/* Last process in the chain does nothing else */
			if(index < N)
			{
				/* Create new pipe for successive child */
				pipe(right_pipe);
				/* Create child: at next iteration, THIS process will execute
				 * the parent branch */
				child = fork();			
			}	
			else
			{
				/* Exit and awake all the previous processes in the chain */
				exit_flag = 1;
				shmdt(shared_mem_ptr);
			}
		}//end_child
		else
		{		
			close(right_pipe[0]);			
			
			/* Read current value from shared memory, to get the index */
			memcpy(&index, shared_mem_ptr, sizeof(int));
			/* Prepare value to send. Notice that the value of 
			 * 'received_value' comes from the last iteration, where THIS 
			 * process was child */
			value_to_send = fibonacci[index] + received_value;

			/* Update value of shared memory */
			index++;
			memcpy(shared_mem_ptr, &index, sizeof(int));

			/* Write the value to the local end of the pipe, and to standard output */
			write(right_pipe[1], &value_to_send, sizeof(int));
			fprintf(stdout, "(!) Process %d at index %d writes %d\n", 
				getpid(), index, value_to_send);
			/* Make EOF visible to read-end of pipe */
			close(right_pipe[1]);	

			/* Wait for child to finish */
			if(index < N)
			{
				waitpid(child, NULL, 0);
			}

			if(index == N - 1)
			{		
				exit_flag = 1;
				shmdt(shared_mem_ptr);
			}

			#ifdef DEBUG
			fprintf(stderr, "Process %d catches termination of %d\n", getpid(), child);
			#endif
			exit(0);
		}//end_father
	}//end_while

	shmctl(shared_mem_id, IPC_RMID, NULL);
	shmdt(shared_mem_ptr);
	free(fibonacci);
	return 0;
}

void get_fibonacci_sequence(int *fibonacci, int n)
{
	int index;

	/* Initialization */
	fibonacci[0] = 0;
	fibonacci[1] = 1;

	for(index = 2; index < n; index++)
	{
		fibonacci[index] = fibonacci[index - 2] + fibonacci[index - 1];
	}

	/* Result will be found in the argument */
}

void print_sequence(int *fibonacci, int n)
{
	int index;

	for(index = 0; index < n; index++)
	{
		fprintf(stderr, "%d ", fibonacci[index]);
	}
	fprintf(stderr, "\n");
}

