#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define DEFAULT 	3

int main(int argc, char *argv[])
{
	int num_of_processes, j;

	if(argc < 2)
	{
		num_of_processes = DEFAULT;
	}
	else
	{
		num_of_processes = atoi(argv[1]);
	}

	for(j = 0; j < num_of_processes; j++)
	{
		fork();
	}

	fprintf(stdout, "X\n");

	return 0;
}

