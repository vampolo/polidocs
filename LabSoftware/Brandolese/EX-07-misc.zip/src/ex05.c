#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>

int j;

int main()
{
    pid_t pid;
    int *k;

    /* Initialization */
    k = (int *)malloc(sizeof(int));
    j = 1;
    *k = 2;	

    /* Create child process */
    pid = fork();
    if(pid == 0)
    {
        j = 45;
		(*k)++;		
        printf("CHILD : \t"
            "j = %d\t"
            "k = %d\n", j, *k);
        exit(0);
    }
    else
    {
        wait(NULL);		
        printf("PARENT :\t"
            "j = %d\t"
            "k = %d\n", j, *k);
        free(k);
        return 0;
    }
}

