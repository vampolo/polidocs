#include <stdio.h>		
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <signal.h>		/* Signal handlers */
#include <string.h>		/* memset() and memcpy() */
#include <unistd.h>		/* pause() */

/* Maximum buffer size */
#define BUFFER_SIZE		100

/* Buffer related utilities */
#define INIT_BUFFER		"111111111122222222223333333333444444444555555555556666666666"
#define MODIFY_BUFFER	"AAAAAAAAAA"

/* Define size of read */
#define FIRST_READ		20
#define FIRST_WRITE		10
#define SECOND_READ		10

/* Handler routine */
void handler(int signal);

int main()
{
	int s_id;
	pid_t child;
	struct sigaction sa_child;
	char buffer[BUFFER_SIZE];
	char *shared_mem, *smem_ptr;

	/* Initialize handler structs */
	memset(&sa_child, 0, sizeof(struct sigaction));
	sa_child.sa_handler = &handler;

	/* Create segment */
	s_id = shmget(IPC_PRIVATE, sizeof(char) * BUFFER_SIZE, IPC_CREAT | S_IRUSR | S_IWUSR);
	if(s_id == -1)
	{
		fprintf(stderr, "An error occurred while creating shared memory segment\n");
		return -1;
	}

	/* Attach memory segment */
	shared_mem = shmat(s_id, NULL, 0);
	/* Initialize memory segment */
	sprintf(shared_mem, "%s", INIT_BUFFER);
	
	child = fork();
	if(child == 0)
	{		
		/* Register on signal SIGUSR1 */
		sigaction(SIGUSR1, &sa_child, NULL);
		
		/* Attach memory segment */
		shared_mem = shmat(s_id, NULL, 0);

		/* Wait signal from father process */
		pause();

		/* Read from memory */
		memcpy(&buffer[0], shared_mem, sizeof(char) * FIRST_READ);
		buffer[FIRST_READ] = '\0';
		printf("Child read %s\n", buffer);
	
		exit(0);
	}
	else
	{
		/* Perform operations */
		memcpy(&buffer[0], shared_mem, sizeof(char) * FIRST_READ);
		buffer[FIRST_READ] = '\0';
		printf("Parent process read %s\n", buffer);
		memcpy(shared_mem, MODIFY_BUFFER, sizeof(char) * FIRST_WRITE);
		
		/* Signal child */
		kill(child, SIGUSR1);

		/* Wait child to finish writing */
		wait(NULL);

		smem_ptr = shared_mem + 20;
		memcpy(&buffer[0], smem_ptr, sizeof(char) * SECOND_READ);
		buffer[SECOND_READ] = '\0';
		printf("Parent read %s\n", buffer);

		return 0;
	}
}//end_main

void handler(int signal)
{	
	/* Return immediately */
	return;
}

