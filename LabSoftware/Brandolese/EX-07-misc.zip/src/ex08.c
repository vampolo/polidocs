#include <stdio.h>			/* Standard I/O */
#include <stdlib.h>			/* exit() */
#include <sys/types.h>		/* Flags */
#include <sys/stat.h>		/* Other flags */
#include <sys/ipc.h>		/* IPC-related */
#include <sys/shm.h> 		/* Shared memory utilities */

int main()
{
	pid_t child;
	char *shared_memory;
	int var, segment_id;

	/* Create segment in memory */
	segment_id = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | S_IRUSR | S_IWUSR);
	if(segment_id == -1)
	{
		fprintf(stderr, "An error during creating memory segment\n");
		return -1;
	}

	/* Attach and initialize memory */
	shared_memory = shmat(segment_id, NULL, 0);
	var = 10;
	sprintf(shared_memory, "%d", var);	

	/* Create the process */
	child = fork();
	if(child == 0)
	{	
		/* Attach memory segment */
		shared_memory = shmat(segment_id, NULL, 0);
		var = 11;
		/* Write new value to memory */
		sprintf(shared_memory, "%d", var);
		/* Detach memory */
		shmdt(shared_memory);

		exit(0);
	}
	else
	{					
		wait(NULL);		
		sscanf(shared_memory, "%d", &var);
		printf("Parent read %d\n", var);

		return 0;
	}
}

