#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

/* Maximu mnumber of chairs */
#define MAX_CHAIRS		10
#define UPPER_BOUND		100

/* Prototype functions for customer and barber */
void *customer(void *unused);
void *barber(void *unused);

void cut_hair(void);

/* Mutex, this is used to allow the customer to mutually access
 * the chair in the barber shop, so that to book its turn */
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
/* Available chairs */
int available_chairs = MAX_CHAIRS;

/* How many customers are waiting? */
sem_t queue_length;
/* Is the barber ready? */
sem_t barber_is_ready;

int main(int argc, char *argv[])
{
	pthread_t barber_thread, *customer_threads;
	int num_of_customers, j;

	num_of_customers = atoi(argv[1]);
	customer_threads = (pthread_t *)malloc(sizeof(pthread_t) * num_of_customers);

	/* Initialize semaphores */
	sem_init(&queue_length, 0, 0);
	sem_init(&barber_is_ready, 0, 1);

	/* Create threads */
	pthread_create(&barber_thread, NULL, barber, NULL);
	for(j = 0; j < num_of_customers; j++)
	{
		pthread_create(&customer_threads[j], NULL, customer, NULL);
	}

	/* Join all threads */
	for(j = 0; j < num_of_customers; j++)
	{
		pthread_join(customer_threads[j], NULL);
	}
	pthread_join(barber_thread, NULL);

	free(customer_threads);

	return 0;	
}

void *customer(void *unused)
{
	/* Acquire lock */
	pthread_mutex_lock(&mutex);
	
	/* Check if there is a place to sit on */
	if(available_chairs == 0)
	{
		fprintf(stderr, "++ Thread [%d] exits, no available chairs\n", 
			pthread_self());
		pthread_mutex_unlock(&mutex);
		pthread_exit(0);
	}
	
	/* ELSE branch, there is room in the barber shop */
	available_chairs--;
	pthread_mutex_unlock(&mutex);
	/* Another customer is waiting */
	sem_post(&queue_length);
	/* Wait until barber ready */
	fprintf(stderr, "++ Thread [%d] is waiting for the barber to be ready...\n", 
		pthread_self());
	sem_wait(&barber_is_ready);
	
	/* Now we can leave the chair */
	pthread_mutex_lock(&mutex);
	available_chairs++;
	pthread_mutex_unlock(&mutex);	
	/* At this point the barber is servicing the customer */
	cut_hair();
}

void *barber(void *unused)
{
	/* The barber wait for a customer to be ready */
	while(1)
	{
		/* Wait for a customer to arrive */
		fprintf(stderr, "++ No one in the queue...");
		sem_wait(&queue_length);
		fprintf(stderr, "Someone arrived\n");
		/* Now there is a customer ready: do work! */
		fprintf(stderr, "++ Barber is working!\n");
		sleep(2);
		/* The barber is again available */
		sem_post(&barber_is_ready);
	}	
}

void cut_hair(void)
{
	fprintf(stderr, "++ Thread [%d] is cutting his hair!\n", pthread_self());
}

