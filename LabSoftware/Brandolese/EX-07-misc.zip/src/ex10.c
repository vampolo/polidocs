#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>		/* Memory mapping functionalities */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

/* Maximum buffer size */
#define BUFFER_SIZE		100

/* Buffer related utilities */
#define MODIFY_BUFFER	"AAAAAAAAAA"

/* Define size of read */
#define FIRST_READ		20
#define FIRST_WRITE		10
#define SECOND_READ		10

/* Handler routine */
void handler(int signal);

int main()
{
	int fd;
	pid_t child;
	struct sigaction sa_child;
	char *mem_addr, *smem_ptr;
	char buffer[BUFFER_SIZE];

	/* Initialize handler structs */
	memset(&sa_child, 0, sizeof(struct sigaction));
	sa_child.sa_handler = &handler;

	/* Open file */
	fd = open("./data/pippo", O_RDWR);
	if(fd == -1)
	{
		fprintf(stderr, "An error occurred while opening the file\n");
		return -1;
	}

	/* Map file to process memory */
	mem_addr = (char *)mmap(NULL, sizeof(char) * BUFFER_SIZE, 
		PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	/* Check if MAP_FAILED is set */
	if(mem_addr == (void *)-1)
	{
		fprintf(stderr, "An error occurred while mapping file to memory\n");
		return -1;
	}

	/* We can now close the file descriptor */
	close(fd);

	/* Fork */
	child = fork();
	if(child == 0)
	{
		sigaction(SIGUSR1, &sa_child, NULL);	
		pause();
	
		/* Child processes will inherit the mapping, so just use it! */
		memcpy(&buffer[0], mem_addr, sizeof(char) * FIRST_READ);
		buffer[FIRST_READ] = '\0';
		printf("Child read %s\n", buffer);

		exit(0);
	}
	else	
	{
		/* Read first FIRST_READ bytes */
		memcpy(&buffer[0], mem_addr, FIRST_READ);
		buffer[FIRST_READ] = '\0';
		printf("Parent read %s\n", buffer);
		memcpy(mem_addr, MODIFY_BUFFER, sizeof(char) * FIRST_WRITE);

		kill(child, SIGUSR1);

		/* Wait the child to write someting */
		wait(NULL);

		smem_ptr = mem_addr + 20;
		memcpy(&buffer[0], smem_ptr, sizeof(char) * SECOND_READ);
		buffer[SECOND_READ] = '\0';
		printf("Parent read %s\n", buffer);

		return 0;
	}
}

void handler(int signal)
{
	return;
}

