/*
 * Producer/consumer using semaphores (for threads). The current
 * implementation will execute only one write and read transaction
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

/* The buffer */
char buffer;
/* Semaphores for the buffer access */
sem_t empty, full;

/* Producer and consumers thread routine */
void *producer(void *unused);
void *consumer(void *unused);

int main()
{
	pthread_t consumer_thread, producer_thread;

	/* Initialize semaphores */
	sem_init(&empty, 0, 1);	
	sem_init(&full, 0, 0);
	/* Initialize buffer */
	buffer = 'X';

	/* Start tasks */
	pthread_create(&producer_thread, NULL, producer, NULL);
	pthread_create(&consumer_thread, NULL, consumer, NULL);

	/* Wait for threads to finish */
	pthread_join(producer_thread, NULL);
	pthread_join(consumer_thread, NULL);
		
	return 0;
}

void *producer(void *unused)
{
	/* Wait for the buffer to be empty */
	sem_wait(&empty);
	/* Write data into buffer */
	buffer = 'p';
	/* Wake up blocked threads */
	sem_post(&full);
}

void *consumer(void *unused)
{
	/* Wait for the buffer to be empty */
	sem_wait(&full);
	fprintf(stderr, "Consumer thread [%d] reads %c\n", pthread_self(), buffer);
	sem_post(&empty);
}

