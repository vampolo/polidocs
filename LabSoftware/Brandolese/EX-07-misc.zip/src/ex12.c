#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>

#define PROGRAM_NAME		"fibonacci"
#define PROGRAM_VERSION		"1.0"

/* Recursive function for the Fibonacci series for the N-th value */
int fibonacci(int depth);

/* Print usage synopsys */
void usage(void);

/* Print version */
void version(void);

int main(int argc, char *argv[])
{
	pid_t child;
	/* The depth of the series to be computed */
	int depth, i, next_option;
	unsigned long int value;

	/* Structures for the getopt_long utility */
	const char *const short_options = "hvd:";
	const struct option long_options[] = 
	{
		{"help", 0, NULL, 'h'},
		{"version", 0, NULL, 'v'},
		{"depth", 1, NULL, 'd'},
		{NULL, 0, NULL, 0}
	};

	/* Check arguments from command line */
	if(argc < 2)
	{
		fprintf(stderr, "You have to specify a value for N\n");
		usage();
	}

	do
	{
		next_option = getopt_long(argc, argv, short_options, long_options, NULL);
		/* Switch over current option */
		switch(next_option)
		{
			case -1 :
				break;
		
			case 'h' :
				usage();

			case 'v' :
				version();
		
			case 'd' :
				depth = atoi(optarg);
				break;

			default :
				usage();
		}
	} while(next_option != -1);

	/* At this point depth contains the depth of the Fibonacci series */
	child = fork();
	if(child == 0)
	{
		fprintf(stdout, "Child process called with N = %d\n", depth);

		/* Compute the Fibonacci series */
		value = fibonacci(depth - 1);
		
		/* Print Fibonacci value */
		fprintf(stdout, "The %d-th element of the Fibonacci series is %d\n", 
			depth, value);

		exit(0);
	}
	else
	{
		wait(NULL);
		fprintf(stdout, "Parent process exits\n");
		return 0;
	}
}

int fibonacci(int depth)
{
	/* Base rules and recursion */
	if(depth < 0)
	{
		return -1;
	}
	else if(depth == 0)
	{
		return 0;
	}
	else if(depth == 1 || depth == 2)
	{
		return 1;
	}	
	else
	{
		return (fibonacci(depth - 1) + fibonacci(depth - 2));
	}
}

void usage(void)
{
	fprintf(stdout, 
		"*******************************************************\n"
		"***   Welcome to the Fibonacci series calculator!   ***\n"
		"*******************************************************\n"
		"Valid options are:\n"
		"   -h, --help           			prints this message\n"
		"   -v, --version		 			prints version information\n"
		"   -d <value>, --depth	<value>		defines the depth of the series\n"
	);

	exit(0);
}

void version(void)
{
	fprintf(stdout, "%s - version %s\n", PROGRAM_NAME, PROGRAM_VERSION);
	exit(0);
}

