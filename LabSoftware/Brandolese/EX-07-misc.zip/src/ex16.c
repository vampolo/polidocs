#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define BUFFER_SIZE		50
static int buffer[BUFFER_SIZE];
static int empty;

/* Mutex for sync'ng */
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* Prototype for reader */
void *reader(void *unused);
/* Prototype for writer */
void *writer(void *unused);

int main()
{
	int i;
	/* Single writer */
	pthread_t wr;
	/* Multiple readers */
	pthread_t rs[3];

	/* Initialize buffer first */
	sprintf((void *)buffer, "%s", "EMPTY");
	empty = 1;

	/* Create threads */
	pthread_create(&wr, NULL, writer, NULL);
	fprintf(stdout, "Thread [%d] created\n", wr);
	for(i = 0; i < 3; i++)
	{
		pthread_create(&rs[i], NULL, reader, NULL);
		fprintf(stdout, "Thread [%d] created\n", rs[i]);
	}

	/* Wait for all thread to finish */
	pthread_join(wr, NULL);
	pthread_join(rs[0], NULL);
	pthread_join(rs[1], NULL);
	pthread_join(rs[2], NULL);

	fprintf(stdout, "All threads joined\n");

	return 0;
}

void *writer(void *unused)
{
	/* Acquire lock */
	pthread_mutex_lock(&mutex);
	fprintf(stdout, "++ Producer writing to buffer\n");	
	sprintf((void *)buffer, "Producer %d greets you!", pthread_self());	
	empty = 0;
	pthread_mutex_unlock(&mutex);

	return NULL;	
}

void *reader(void *unused)
{
	while(empty)
	{ }
		
	/* Now thread can read from buffer */
	pthread_mutex_lock(&mutex);
	fprintf(stdout, "++ Consumer [%d] reads %s\n", 
		pthread_self(), buffer);
	pthread_mutex_unlock(&mutex);

	return NULL;
}

