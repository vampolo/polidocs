#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main()
{
	/* Pipe descriptors
	 * 	fd[0] will contain the Read end-point
	 * 	fd[1] will contain the Write end-point */
	int fd[2];
	pid_t child;
	char buffer[] = "Hello World from IPC pipes!\n";	
	char byte;

	int a;

	/* Create the pipe */
	pipe(fd);

	/* Fork */
	child = fork();

	/* Now both the father and the child process share the same fd values */
	if(child == 0)
	{		
		/* Let the child be the reader, so close the write descriptor */
		close(fd[1]);
		
		/* Read one byte at a time */
		while(read(fd[0], &byte, 1) > 0)
		{
			fprintf(stdout, "%c", byte);			
		}

		/* Ended up writing */
		exit(0);
	}
	else
	{
		/* Let the father write to the pipe, close read side */
		close(fd[0]);
		/* Write some data */
		write(fd[1], &buffer[0], strlen(buffer));
		/* Close write point */
		close(fd[1]);

		/* Wait for the child to finish */
		wait(NULL);
		
		return 0;
	}
}

