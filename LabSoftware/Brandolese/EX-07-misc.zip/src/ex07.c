/*
 * In order to read the file, we use mapped memory. Data will be read from the 
 * file, and result will be written to anothre text file, using mapped memory again.
 * The main process (P1, the father) is responsible to initialize the required
 * data structures, and to open, read, and write data from/to file. 
 */

/*-------------------- INCLUDES -----------------------*/
#include <stdio.h>			/* Standard I/O */
#include <stdlib.h>			
#include <pthread.h>		/* PTHREAD library */
#include <unistd.h>			/* Process management */
#include <sys/ipc.h>		/* IPC related */
#include <sys/shm.h>		/* Shared memory */
#include <sys/stat.h>		/* Flags */
#include <sys/types.h>
#include <string.h>			/* memcpy() */
#include <sys/wait.h>		/* wait() and waitpid() */
#include <fcntl.h>
#include <sys/mman.h>		/* Memory-mapped related */
#include <assert.h>			/* assert() */

/*------------------- DEFINES --------------------*/
/* Define the initial matrices value */
#define INITIALIZATION_VALUE	-1

/* Maximum matrix dimension */
#define MAX_N	10

/* Upper bound for memory mapping (in bytes) */
#define GET_MEMORY_MAP_SIZE(a)			(2 * a * a * sizeof(int))
#define MEMORY_MAP_SIZE_UPPER_BOUND 	GET_MEMORY_MAP_SIZE(MAX_N)
/* Upper bound for shared memory segment (in bytes) */
#define GET_SHARED_MEMORY_SIZE(a)		(a * a * sizeof(int))
#define SHARED_MEMORY_SIZE_UPPER_BOUND	GET_SHARED_MEMORY_SIZE(MAX_N)

/* Offsets in shared memory segment */
#define BASE_OFFSET					0x00000000
#define BASE_ADDRESS(a)				a + BASE_OFFSET
#define RESULT_MATRIX_OFFSET		0x00000000
#define RESULT_MATRIX_ADDRESS(a)	BASE_ADDRESS(a) + RESULT_MATRIX_OFFSET
#define LEFT_OPERAND_OFFSET			(N * N)
#define LEFT_OPERAND_ADDRESS(a)		BASE_ADDRESS(a) + LEFT_OPERAND_OFFSET
#define RIGHT_OPERAND_OFFSET		(N * N * 2)
#define RIGHT_OPERAND_ADDRESS(a)	BASE_ADDRESS(a) + RIGHT_OPERAND_OFFSET 

/* This macro computes the addrss of the memory cell where the
 * element within the result matrix will be stored by the current
 * executing thread 
 * 		'a' is the base address of the shared memory segment
 * 		'b' is the ID of the executing thread
 */
#define GET_SHARED_MEMORY_WRITE_POINTER(a,b) \
	(RESULT_MATRIX_ADDRESS(a) + b)

/* Used for debug purposes */
#define DEBUG

/* Miscellanea defines */
#define TOTAL_NUMBER_OF_READS(a)	a * a * 2
#define READ_SIZE(a)				a * a * sizeof(int)
#define OUTPUT_FILE_MAP_SIZE		256
#define STARTING_STRING				"xxxx,"
#define ENDING_STRING				"xxxx"

/*----------------------- DATA STRUCTURES ------------------------*/
/* This struct is used as an argument to threads */
typedef struct {
	/* Used to load computation on different threads */
	int current_thread;		
	/* Location of the memory where to store the result */
	int *shared_mem_location;
	/* Size of the matrix */
	int N;
} thread_arg_t;

/*--------------------- PROTOTYPES -----------------------*/
void initialize_matrix(int *matrix, int N);
void print_matrix(int *matrix, int N);
void *multiply(void *thread_args);
int get_num_of_chars_read(int value);
	
/*----------------------- GLOBAL VARIABLES ----------------------------*/
/* Mutex to access shared memory */
pthread_mutex_t mutex;

/* Thread condition variable */
int done;
pthread_cond_t thread_done_cond_var;
pthread_mutex_t thread_done_mutex;

/*---------------------------_ MAIN FUNCTION ------------------------*/
int main(int argc, char *argv[])
{
	/* Matrices are represented as a linear array */
	int *matrix, *left_operand, *right_operand;
	/* Shared memory pointer */
	int *shared_mem;
	/* Shared memory identifier */
	int shared_mem_id;
	/* Each thread will be assigned an element of the result matrix */
	pthread_t *threads;
	thread_arg_t *thread_args;
	/* The multi-threaded application will be executed in a second process */
	pid_t child;
	/* The file descriptor where to read data from */
	int fd;
	/* Auxiliary high-level file access, to retrieve the dimension of the file */
	FILE *fd_;
	/* The matrix dimension */
	int N;
	/* Auxiliary variables */
	int index, value, file_length, number_of_reads, res;
	/* The mapped memory pointers */
	char *file_memory;
	char *file_memory_read_ptr;
	/* The offset for R/W operations */
	int offset;

	/* Check arguments; first (and only) argument represents the dimension of
	 * the matrix */
	if(argc < 2)
	{
		fprintf(stderr, "Error! You have to specify matrix dimension.\n");
		return -1;
	}
	
	/* Get matrix dimension */
	N = atoi(argv[1]);
	if(N > MAX_N)
	{
		fprintf(stderr, "Error! Too much high value for N : %d\n", N);
		return -1;
	}

	/* Create and initialize mutex */
	res = pthread_mutex_init(&mutex, NULL);
	if(res != 0)
	{
		fprintf(stderr, "Unable to initaliza mutex\n");
		return -1;
	}

	/* Get descriptor to file */
	fd = open("./data/matrix", O_RDWR);
	if(fd == -1)
	{
		fprintf(stderr, "Unable to open file\n");
		return -1;	
	}

	/* Get file dimension */
	fd_ = fdopen(fd, "r");
	if(fd_ == NULL)
	{
		fprintf(stderr, "Unable to associate FILE-stream to file descriptor\n");
		close(fd);
		return -1;
	}
	fseek(fd_, 0, SEEK_END);
	file_length = ftell(fd_);	
	if(file_length > MEMORY_MAP_SIZE_UPPER_BOUND)
	{
		fprintf(stderr, "Unable to request such huge mapping : %d\n", 
			file_length);			
		close(fd);		
		return -1;
	}

	/* Map file to memory */
	file_memory = (char *)mmap(
		NULL, 					/* Let the system decide where to put the mapping */
		file_length,			/* Mapping length */
		PROT_READ | PROT_WRITE, /* Write access not allowed */
		MAP_SHARED, 			/* Visible to other processes */
		fd,						/* File descriptor */
		0);						/* Read from start */
	if(file_memory == (void *)-1)
	{
		fprintf(stderr, "Unable to map file into memory\n");
		close(fd);
		return -1;
	}	
	/* We can close file descriptor; we will use
	 * memory access directly */	
	fclose(fd_);
	close(fd);
	
	/* Allocate and initialize required space */
	thread_args = (thread_arg_t *)calloc(N * N, sizeof(thread_arg_t));
	threads = (pthread_t *)calloc(N * N, sizeof(pthread_t));
	/* Space for left and right operands, and result matrix */
	left_operand = (int *)malloc(sizeof(int) * N * N);
	initialize_matrix(left_operand, N);
	right_operand = (int *)malloc(sizeof(int) * N * N);
	initialize_matrix(right_operand, N);
	matrix = (int *)malloc(sizeof(int) * N * N);
	initialize_matrix(matrix, N);

	/* Start reading from memory contents */
	index = 0;
	number_of_reads = 0;
	/* Start reading from the beginning of the memory region */
	file_memory_read_ptr = file_memory;

	/* We statically know EXACTLY how many numbers to be read, so we use 
	 * this information to prevent memory accesses from segmentation faults */
	while(number_of_reads != TOTAL_NUMBER_OF_READS(N))
	{
		#ifdef DEBUG
		fprintf(stderr, "Attempt to access address %p\n", file_memory_read_ptr);
		#endif		
		sscanf((void *)file_memory_read_ptr, "%d", &value);
		/* How many ASCII chars have been read? */
		offset = get_num_of_chars_read(value);
		/* Add single byte offset for ':' or ',' */
		offset += 0x00000001;
		/* And update memory reference */
		file_memory_read_ptr += offset;	
					
		/* First half contains the left-operand */
		if(index < TOTAL_NUMBER_OF_READS(N) / 2)
		{		
			left_operand[index] = value;
		}
		/* Second half contains the right-operand */
		else
		{		
			right_operand[index - N * N] = value;
		}
		index++;
		number_of_reads++;
	}//end_reading_memory_contents

	/* We can safely unmap memory, since we do not need it furthermore */
	munmap(file_memory, file_length);

	#ifdef DEBUG
	fprintf(stderr, "left_operand is :\n");
	print_matrix(left_operand, N);
	fprintf(stderr, "right_operand is :\n");
	print_matrix(right_operand, N);
	#endif

	/* At this point we have to prepare the shared memroy segment. We need 3 blocks: 
	 * one for the left operand, one for the right operand and one for the result */
	shared_mem_id = shmget(IPC_PRIVATE, GET_SHARED_MEMORY_SIZE(N), IPC_CREAT | S_IRUSR | S_IWUSR);
	if(shared_mem_id == -1 || GET_SHARED_MEMORY_SIZE(N) > SHARED_MEMORY_SIZE_UPPER_BOUND)
	{
		fprintf(stderr, "Unable to allocate shared memory segmet\n");
		free(matrix);
		free(right_operand);
		free(left_operand);
		free(threads);
		free(thread_args);
		return -1;
	}
	#ifdef DEBUG
	fprintf(stderr, "Shared memory segment created with ID %d\n", shared_mem_id);
	#endif

	/* Attach shared memory segment to current process */
	shared_mem = shmat(shared_mem_id, 0, 0);
	#ifdef DEBUG
	fprintf(stderr, "Process %d gets shared memory reference at %p\n", 
		getpid(), shared_mem);
	#endif

	/* Copy matrices in shared memory */
	memcpy(RESULT_MATRIX_ADDRESS(shared_mem), matrix, sizeof(int) * N * N);	
	#ifdef DEBUG
	fprintf(stderr, "matrix at %p\n", RESULT_MATRIX_ADDRESS(shared_mem));
	#endif
	memcpy(LEFT_OPERAND_ADDRESS(shared_mem), left_operand, sizeof(int) * N * N);
	#ifdef DEBUG
	fprintf(stderr, "left_operand at %p\n", LEFT_OPERAND_ADDRESS(shared_mem));
	#endif
	memcpy(RIGHT_OPERAND_ADDRESS(shared_mem), right_operand, sizeof(int) * N * N);	
	#ifdef DEBUG
	fprintf(stderr, "right_operand at %p\n", RIGHT_OPERAND_ADDRESS(shared_mem));
	#endif

	/* Create the child process */
	child = fork();
	if(child == 0)
	{
		/* Process-local variables */
		int current_thread;

		/* Initialize mutex and condition variable */
		res = pthread_mutex_init(&thread_done_mutex, NULL);
		if(res != 0)
		{
			fprintf(stderr, "Unable to initialize mutex\n");
			return -1;
		}
		res = pthread_cond_init(&thread_done_cond_var, NULL);
		if(res != 0)
		{
			fprintf(stderr, "Unable to initialize condition variable\n");
			pthread_mutex_destroy(&thread_done_mutex);
			return -1;
		}
		done = 0;

		/* Attach shared memory segment */
		shared_mem = shmat(shared_mem_id, 0, 0);
		#ifdef DEBUG
		fprintf(stderr, "** Shared memory segment reference at %p\n", shared_mem);
		#endif

		/* Child process creates a set of threads, one for each element in the result matrix */
		for(current_thread = 0; current_thread < N * N; current_thread++)
		{
			#ifdef DEBUG
			fprintf(stderr, "---- %d ----\n", current_thread);
			#endif

			/* Initialize thread arguments */
			thread_args[current_thread].current_thread = current_thread;
			thread_args[current_thread].shared_mem_location = shared_mem;
			thread_args[current_thread].N = N;

			#ifdef DEBUG
			fprintf(stderr, "** Thread spawning with parameters "
				"(%d,%p,%d)\n", current_thread, shared_mem, N);
			#endif

			/* Create thraed and pass arguments to function */
			pthread_create(&threads[current_thread], NULL, multiply, (void *)&thread_args[current_thread]);
			#ifdef DEBUG
			fprintf(stderr, "** [%d] thread created\n", threads[current_thread]);
			#endif
		}

		/* Synchronize with all threads */		
		pthread_mutex_lock(&thread_done_mutex);
		while(done != N * N)		
		{
			pthread_cond_wait(&thread_done_cond_var, &thread_done_mutex);
			#ifdef DEBUG
			fprintf(stderr, "** 'done' reached %d\n", done);
			#endif
		}
		pthread_mutex_unlock(&thread_done_mutex);		
		#ifdef DEBUG
		fprintf(stderr, "** All threads got sync\n");
		#endif

		/* Detach from shared memory */
		shmdt(shared_mem);
		/* Destroy sync mechanisms */
		pthread_cond_destroy(&thread_done_cond_var);
		pthread_mutex_destroy(&thread_done_mutex);

		/* Exit, and awake father process */
		exit(1);
	}
	else
	{
		int status, fd_out, current_index;
		char *fd_out_map;
		/* Let's say that at most 10 ciphers are allowed */
		char matrix_str[OUTPUT_FILE_MAP_SIZE], item_char[10];	
		FILE *fd_out_;
	
		#ifdef DEBUG
		fprintf(stderr, "Child process created; waiting for termination with PID %d\n", child);
		#endif

		/* Wait until child process terminated */
		waitpid(child, &status, 0);

		#ifdef DEBUG
		fprintf(stderr, "Child process terminated with value %d\n", WEXITSTATUS(status));
		#endif

		/* Now we can read back data from the shared memory */
		memcpy((void *)matrix, RESULT_MATRIX_ADDRESS(shared_mem), READ_SIZE(N));		

		/* Print out computed result */
		print_matrix(matrix, N);

		/* Initialize strings */
		memset(matrix_str, 0, strlen(matrix_str));		
	
		/* Backup result matrix on another file */
		fd_out = open("./data/matrix_OUT", O_RDWR, S_IRUSR | S_IWUSR);
		if(fd_out == -1)
		{
			#ifdef DEBUG
			fprintf(stderr, "File does not exist, I shall create it!\n");
			#endif
			/* The file does not exist; we have to create it, and fill it in order
			 * to be able later to write on it through memory mapping. So at first
			 * we have to repeat the open operation with O_CREAT flag */
			fd_out = open("./data/matrix_OUT", O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
		
			/* Now fill it with N*N-1 pairs of type 'value,' and a single 'value'
			 * last pair; 'value' is an integer value with at most 10 ciphers, so we
			 * need (N*N-1)*(10+1)+10 bytes in total */
			for(index = 0; index < N * N - 1; index++)
			{
				strcat(matrix_str, STARTING_STRING);
			}			
			strcat(matrix_str, ENDING_STRING);			
			strcat(matrix_str,"\n");			
			matrix_str[strlen(matrix_str)] = '\0';
			write(fd_out, (void *)&matrix_str[0], sizeof(char) * strlen(matrix_str));
		}//end_preparing_file
		
		/* Map output file into memory, so write to memory directly */		
		fd_out_ = fdopen(fd_out, "r");
		fseek(fd_out_, 0, SEEK_END);
		file_length = ftell(fd_out_);
		#ifdef DEBUG
		fprintf(stderr, "file_length is %d\n", file_length);
		#endif
		if(file_length > OUTPUT_FILE_MAP_SIZE)
		{
			fprintf(stderr, "Too huge mapping!\n");
			fclose(fd_out_);
			close(fd_out);			
			return -1;
		}
		
		/* Get memory mapping */
		fd_out_map = (char *)mmap(NULL, file_length, PROT_WRITE, 
			MAP_SHARED, fd_out, 0);
		if(fd_out_map == (void *)-1)
		{
			fprintf(stderr, "Unable to map file to memory\n");
			close(fd_out);
			return -1;
		}
		#ifdef DEBUG
		fprintf(stderr, "Mapping at %p\n", fd_out_map);
		#endif
		close(fd_out);	
		fclose(fd_out_);

		/* Copy contents result into file/memory */
		memset(matrix_str, 0, strlen(matrix_str));
		memset(item_char, 0, strlen(item_char));
		for(index = 0; index < N * N; index++)
		{
			/* Print one value at a time */
			res = sprintf(item_char, "%d", shared_mem[index]);
			if(index == N * N - 1)
			{
				item_char[res] = '\0';
			}
			else
			{
				item_char[res] = ',';
				item_char[res + 1] = '\0';
			}			
	
			/* Append to string */
			strcat(&matrix_str[0], &item_char[0]);			
			#ifdef DEBUG
			fprintf(stderr, "(%d) string at this point is %s\n", index, matrix_str);
			#endif
		}
	
		/* Copy to memory entire string */
		sprintf(fd_out_map, "%s\n", matrix_str);				
	
		/* Release resources */		
		munmap(fd_out_map, OUTPUT_FILE_MAP_SIZE);		
		pthread_mutex_destroy(&mutex);
		shmdt(shared_mem);
		shmctl(shared_mem_id, IPC_RMID, NULL);
		free(left_operand);
		free(right_operand);
		free(matrix);
		free(thread_args);
		free(threads);

		return 0;
	}
}//end_main

void initialize_matrix(int *matrix, int N)
{
	int i, j;

	/* For each row... */
	for(i = 0; i < N; i++)
	{
		/* ... and for each column... */
		for(j = 0; j < N; j++)
		{
			/* ... initialize to INITIALIZATION_VALUE */
			matrix[i * N + j] = INITIALIZATION_VALUE;
		}
	}
}

void print_matrix(int *matrix, int N)
{
	int i, j;

	/* For each row... */
	for(i = 0; i < N; i++)
	{
		/* ... and for each column... */
		for(j = 0; j < N; j++)
		{
			/* ... print matrix element */
			printf("%2d ", matrix[i * N + j]);
		}
		printf("\n");
	}
}

void *multiply(void *thread_args)
{
	int current_thread_local, row_L, column_L, row_R, column_R, temp, N;
	/* Reference to shared memory segment */
	int *shared_mem_location, *left_operand, *right_operand;
	/* Reference to the EXACT address of the memory cell where to store
	 * the value computed by the current thread */
	int *write_pointer;

	/* Retrieve information */
	current_thread_local = ((thread_arg_t *)thread_args)->current_thread;	
	shared_mem_location = (int *) ((thread_arg_t *)thread_args)->shared_mem_location;
	N = ((thread_arg_t *)thread_args)->N;

	/* Get thread-related information */
	#ifdef DEBUG
	fprintf(stderr, "++ [%d] thread with parameters (%d,%p,%d) executing\n",
		pthread_self(), current_thread_local, shared_mem_location, N);
	#endif

	/* Get pointers to left and right operands */
	left_operand = LEFT_OPERAND_ADDRESS(shared_mem_location);
	#ifdef DEBUG
	fprintf(stderr, "++ [%d] thread reads left operand from %p\n", pthread_self(), left_operand);
	#endif
	right_operand = RIGHT_OPERAND_ADDRESS(shared_mem_location);
	#ifdef DEBUG
	fprintf(stderr, "++ [%d] thread reads right operand from %p\n", pthread_self(), right_operand);
	#endif

	/* Set thread block */
	row_L = current_thread_local / N;	
	column_R = current_thread_local % N;
	row_R = 0;
	column_L = 0;
	#ifdef DEBUG
	fprintf(stderr, "++ [%d] thread responsible for element (%d,%d)\n", 
		pthread_self(), row_L, column_R);
	#endif

	/* The number of addends on the computation of a single element in the result matrix is N */
	temp = 0;
	for(; column_L < N && row_R < N; )
	{
		temp += left_operand[row_L * N + column_L] * right_operand[row_R * N + column_R];
		row_R++;
		column_L++;		
	}	
	#ifdef DEBUG
	fprintf(stderr, "++ [%d] thread sets element at (%d,%d) to %d\n",
		pthread_self(), row_L, column_R, temp);
	#endif

	/* Save data to shared memory location */
	pthread_mutex_lock(&mutex);
	write_pointer = GET_SHARED_MEMORY_WRITE_POINTER(shared_mem_location, current_thread_local);
	#ifdef DEBUG
	fprintf(stderr, "++ [%d] thread writes at %p\n",pthread_self(), write_pointer);
	#endif
	memcpy((void *)write_pointer, (void *)&temp, sizeof(int));
	pthread_mutex_unlock(&mutex);

	/* Count up conditional variable */
	pthread_mutex_lock(&thread_done_mutex);
	done++;
	pthread_cond_signal(&thread_done_cond_var);
	pthread_mutex_unlock(&thread_done_mutex);	

	/* Exit */
	pthread_exit(NULL);
}

int get_num_of_chars_read(int value)
{
	/* We are interested in knowing how many ciphers the integer value is composed of; 
	 * in this way, we will know exactly how many ASCII characters have been read from 
	 * the text file; the result is the offset by which we have to move the memory pointer
	 * to the next integer value */
	int count;
	
	/* At least one */
	count = 1;

	/* Divide by 10 at each iteration */
	while(value > 9)
	{
		value /= 10;
		count++;
	}

	return count;
}

