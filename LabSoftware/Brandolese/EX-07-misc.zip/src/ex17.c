#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>	/* Thread-related semaphores */
#include <pthread.h>

/* Producer/consumer functions */
void *writer(void *unused);
void *reader(void *unused);

/* Semaphore variable */ 
sem_t sem_read, sem_write;

/* Char buffer */
#define BUFFER_SIZE		50
static char buffer[BUFFER_SIZE];

/* Barrier */
pthread_barrier_t barrier;

int main()
{
	int res;
	pthread_t thread_writer, thread_reader;
	
	res = sem_init(&sem_read, 0, 1);
	if(res == -1)
	{
		fprintf(stderr, "Unable to create R semaphore\n");	
		return -1;	
	}
	res = sem_init(&sem_write, 0, 0);
	if(res == -1)
	{
		fprintf(stderr, "Unable to create W semaphore\n");
		return -1;
	}
	
	/* Init barrier */
	pthread_barrier_init(&barrier, NULL, 3);

	/* Create threads */	
	pthread_create(&thread_writer, NULL, writer, NULL);
	pthread_create(&thread_reader, NULL, reader, NULL);

	/* Join threads through barriers */
	pthread_barrier_wait(&barrier);
	pthread_barrier_destroy(&barrier);
	fprintf(stdout, "All thread joined\n");

	return 0;
}

void *writer(void *unused)
{			
	sem_wait(&sem_read);
	sprintf((void *)buffer, "** Thread [%d] greets you! **", pthread_self());

	/* Buffer now is not empty */
	sem_post(&sem_write);
	
	pthread_barrier_wait(&barrier);
	return NULL;	
}

void *reader(void *unused)
{
	/* Wait until buffer is not empty */
	sem_wait(&sem_write);
	fprintf(stdout, "Thread [%d] reading \"%s\" from buffer\n", 
		pthread_self(), buffer);

	
	sem_post(&sem_read);

	pthread_barrier_wait(&barrier);
	return NULL;
}

