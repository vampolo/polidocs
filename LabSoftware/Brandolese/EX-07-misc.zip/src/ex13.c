#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>

#define PROGRAM_NAME		"fibonacci"
#define PROGRAM_VERSION		"1.0"
#define MAX_SEQUENCE_SIZE	20

/* Data structure that is shared between 
 * the processes in the shared memory segment */
typedef struct 
{
	unsigned int fibonacci_sequence[MAX_SEQUENCE_SIZE];
	unsigned int sequence_size;
} shared_data_t;

/* Print usage synopsys */
void usage(void);

/* Print version */
void version(void);

int main(int argc, char *argv[])
{
	pid_t child;
	/* The depth of the series to be computed */
	int depth, next_option, i;
	unsigned long int value;
	int segment_id;
	char *shared_memory_ptr;
	shared_data_t shared_data;

	/* Structures for the getopt_long utility */
	const char *const short_options = "hvd:";
	const struct option long_options[] = 
	{
		{"help", 0, NULL, 'h'},
		{"version", 0, NULL, 'v'},
		{"depth", 1, NULL, 'd'},
		{NULL, 0, NULL, 0}
	};

	/* Check arguments from command line */
	if(argc < 2)
	{
		fprintf(stderr, "You have to specify a value for N\n");
		usage();
	}

	do
	{
		next_option = getopt_long(argc, argv, short_options, long_options, NULL);
		/* Switch over current option */
		switch(next_option)
		{
			case -1 :
				break;
		
			case 'h' :
				usage();

			case 'v' :
				version();
		
			case 'd' :
				if(atoi(optarg) > MAX_SEQUENCE_SIZE || atoi(optarg) < 0)
				{
					shared_data.sequence_size = 1;
				}
				else
				{
					shared_data.sequence_size = atoi(optarg);
				}
				break;

			default :
				usage();
		}
	} while(next_option != -1);

	/* Create shared memory segment */
	segment_id = shmget(IPC_PRIVATE, sizeof(shared_data), 
		IPC_CREAT | S_IRUSR | S_IWUSR);
	if(segment_id == -1)
	{
		fprintf(stderr, "An error occurred while creating the shared memory segment\n");
		return -1;
	}

	/* Attach the memory segment */
	shared_memory_ptr = (char *)shmat(segment_id, NULL, 0);	
	/* Initialize shared data structure */
	memset((void *)shared_data.fibonacci_sequence, 0, 
		sizeof(int) * MAX_SEQUENCE_SIZE);
	/* Copy the created data structure into memory */
	memcpy((void *)shared_memory_ptr, (void *)&shared_data, sizeof(shared_data));
	
	/* Create the child process */
	child = fork();
	if(child == 0)
	{		
		unsigned int *sequence;
	
		/* Attach the memory segment */
		shared_memory_ptr = (char *)shmat(segment_id, NULL, 0);
		/* Copy the data structure in a local variable */
		memcpy((void *)&shared_data, shared_memory_ptr, sizeof(shared_data));

		/* Get reference to the array in the data structure */
		sequence = &(shared_data.fibonacci_sequence[0]);
		
		/* Compute the Fibonacci sequence */
		for(i = 0; i < shared_data.sequence_size; i++)
		{
			if(i == 0)
			{
				sequence[i] = 0;
			}
			else if(i == 1 || i == 2)
			{
				sequence[i] = 1;
			}
			else		
			{
				/* F[i] = F[i-1] + F[i-2] */
				sequence[i] = sequence[i - 1] + sequence[i - 2];
			}
		}	
		
		/* Copy sequence into shared memory */
		memcpy((void *)&(shared_data.fibonacci_sequence[0]), (void *)sequence,
			sizeof(shared_data.fibonacci_sequence)); 
		memcpy((void *)shared_memory_ptr, (void *)&shared_data,
			sizeof(shared_data));

		exit(0);
	}
	else
	{
		wait(NULL);

		/* Read new value */
		memcpy((void *)&shared_data, (void *)shared_memory_ptr, sizeof(shared_data));
		/* Print sequence */
		fprintf(stdout, "Parent process reads back value from share memory\n");
		for(i = 0; i < shared_data.sequence_size; i++)
		{
			fprintf(stdout, "%d ", shared_data.fibonacci_sequence[i]);
		}
		fprintf(stdout, "\n");

		return 0;
	}
}

void usage(void)
{
	fprintf(stdout, 
		"*******************************************************\n"
		"***   Welcome to the Fibonacci series calculator!   ***\n"
		"*******************************************************\n"
		"Valid options are:\n"
		"   -h, --help           			prints this message\n"
		"   -v, --version		 			prints version information\n"
		"   -d <value>, --depth	<value>		defines the depth of the series\n"
	);

	exit(0);
}

void version(void)
{
	fprintf(stdout, "%s - version %s\n", PROGRAM_NAME, PROGRAM_VERSION);
	exit(0);
}

