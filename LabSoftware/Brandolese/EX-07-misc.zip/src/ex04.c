#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>

/* Handler per gestire il segnale SIGUSR1 */
void handler_sigusr1(int signal_number);

/* Handler per SIGUSR2 */
void handler_sigusr2(int signal_number);

/* Contatore */
sig_atomic_t counter = 0;

int main()
{
	struct sigaction sa_sigusr1, 
		sa_sigusr2;			/* Per gestire il segnale SIGUSR1 e SIGUSR2 */
	pid_t pid;				/* PID del figlio */
	int status;				/* Stato d'uscita del figlio */

	/* Inizializzazione */
	memset(&sa_sigusr1, 0, sizeof(struct sigaction));
	sa_sigusr1.sa_handler = &handler_sigusr1;
	memset(&sa_sigusr2, 0, sizeof(struct sigaction));
	sa_sigusr2.sa_handler = &handler_sigusr2;

	pid = fork();	
	if(pid == 0)
	{
		sigaction(SIGUSR1, &sa_sigusr1, NULL);
		sigaction(SIGUSR2, &sa_sigusr2, NULL);
	
		/* La terminazione è controllata dall'utente tramite il segnale 
		 * SIGUSR2 */
		while(1)	
			;
	}
	else
	{
		printf("Il padre attende la terminazione del figlio %d\n", pid);
		wait(&status);
		printf("Processo figlio terminato con %d\n", WEXITSTATUS(status));		
		return 0;
	}
}

void handler_sigusr1(int signal_number)
{
	counter++;
}

void handler_sigusr2(int signal_number)
{
	printf("counter = %d\n", counter);
	exit(1);
}

