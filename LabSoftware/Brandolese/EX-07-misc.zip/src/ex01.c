#include <stdio.h>			/* Standard I/O */
#include <fcntl.h>			/* Funzioni di accesso ai file */
#include <unistd.h>			/* Lettura/scrittura da/su file */
#include <sys/wait.h>		/* Per sincronizzazione processi */
#include <sys/types.h>		/* Tipi di dato usati */
#include <stdlib.h>			/* Funzione exit() */

int main()
{
	int fd;						/* Descrittore di file in comune */	
	char buffer[100];			/* Buffer locale */
	pid_t pid;					/* Pid del figlio */
	char temp[] = "AAAAAAAAAA";	/* Stringa per sostituzione */
	int status;					/* Stato di terminazione del figlio */
	
	fd = open("./data/pippo", O_RDWR);
	if(fd == -1)
	{
		/* Errore nella creazione del descrittore di file */
		fprintf(stderr, "An error occurred while opening specified file.\n");
		return 0;
	}

	/* File aperto correttamente */
	pid = fork();
	if(pid == 0)		/* CHILD */
	{
		fprintf(stdout, "Il processo figlio %d sta andando a letto\n", 
			getpid());
		sleep(10);
		fprintf(stdout, "Il processo figlio %d ora si è svegliato\n", 
			getpid());

		/* Legge i primi 20 byte dal file */
		lseek(fd, 0, SEEK_SET);
		read(fd, &buffer, 20);
		buffer[20] = '\0';
		fprintf(stdout, "Il processo figlio %d ha letto %s\n", 
			getpid(), buffer);
		exit(1);
	}//end_child
	else				/* PARENT */
	{
		/* Leggiamo i primi 20 bytes */
		read(fd, &buffer, 20);	
		buffer[20] = '\0';
		fprintf(stdout, "Il processo padre %d ha letto %s\n", getpid(),
			buffer);
		
		/* Modifichiamo i primi 10 bytes del file */
		lseek(fd, 0, SEEK_SET);
		/* Attenzione al carattere di terminazione! */
		write(fd, temp, sizeof(temp) - 1);	
	
		fprintf(stdout, "Il processo padre %d sta andando a letto\n", getpid());
		sleep(10);
		fprintf(stdout, "Il processo padre %d si è svegliato\n", getpid());
		
		/* Leggiamo altri 10 caratteri dal file */
		read(fd, &buffer, 10);
		buffer[10] = '\0';
		fprintf(stdout, "Il processo padre %d ha letto %s\n", getpid(), 
			buffer);
		wait(&status);
		fprintf(stdout, "Il processo figlio ha terminato con %d\n", 
			WEXITSTATUS(status));

		return 0;
	}//end_parent
}//end_main

