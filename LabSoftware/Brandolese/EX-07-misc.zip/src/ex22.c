SOLUZIONE
Esistono (almeno) due situazioni in cui il sistema si comporta in modo
scorretto: 
	(1) p1->p2->c1->c2->c1
		in questo caso il consumatore C legge da un buffer vuoto
	(2) p1->p2->p1->p2->c1->c2
		in questo caso il produttore produce due volte e sovrascrive
		il dato precedente

Come si intuisce, non è possibile realizzare il meccanismo produttore/consumatore
con un singolo semaforo. Una possibile implementazione per il problema dato 
richiede in effetti due semafori:
	- un semaforo per indicare quando il buffer è pieno;
	- un semaforo per indicaro quando il buffer è vuoto
E' facile notare la (a)simmetria della visione che il consumatore e il produttore
hanno dello stesso buffer (aka la risorsa condivisa). La seguente soluzione, ad
esempio, garantisce mutua esclusione e corretto funzionamento del problema nell'ipotesi
di un buffer a capacità unitaria.

PRODUTTORE:
	semaphore empty = 1;
	semaphore full  = 0;
	while(1)
	{
p1:		down(&empty);
p2:		enter_item(item);
p3:		up(&full);
	}

CONSUMATORE:
	semaphore empty = 1;
	semaphore full	= 0;
	while(1)
	{
c1:		down(&full);
c2:		remove_item(item);
c3:		up(&empty);
	}

Infatti, tramite l'istruzione (p1) P attende che il buffer sia vuoto, il che significa
che è possibile inserire un item nel buffer stesso; (p2) rappresenta la sezione critica, 
in quanto il buffer è la risorsa condivisa; (p3) risveglia i processi consumatore che 
sono bloccati (istruzione (c1)), in quanto sono in attesa di poter leggere qualche dato
dal buffer. Mentre il consumatore è in (c2), il produttore è in (p1), ma deve attendere 
che il consumatore segnali l'avvenuta lettura/rimozione dell'item, tramite (c3).
