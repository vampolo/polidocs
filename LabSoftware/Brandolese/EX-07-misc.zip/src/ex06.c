/*
 * The proposed solution is as follows:
 *
 * Process P1 creates a child P2; process P2 executes a series of operations in a
 * multi-threaded fashion: each thread will be assigned a single element of the result matrix;
 * the communication between the two processes is performed via shared memory; P1 waits until
 * P2 ends its execution, then prints the result that can be found in the attached memory
 * segment.
 *
 * For simplicity, all of this is implemented in a single file; other solutions are accepted,
 * especially thos making use of system() or exec*() and other mechanisms.
 */

#include <stdio.h>			/* Standard I/O */
#include <stdlib.h>			
#include <pthread.h>		/* PTHREAD library */
#include <unistd.h>			/* Process management */
#include <sys/ipc.h>		/* IPC related */
#include <sys/shm.h>		/* Shared memory */
#include <sys/stat.h>		/* Flags */
#include <sys/types.h>
#include <string.h>			/* memcpy() */
#include <sys/wait.h>		/* wait() and waitpid() */

/* The matrix dimension */
#define N	5

/* This struct is used as an argument to threads */
typedef struct {
	/* Used to load computation on different threads */
	int current_thread;		
	/* Location of the memory where to store the result */
	void *shared_mem_location;
} thread_arg_t;

/* Fuction prototypes */
void initialize_matrix(int *matrix);
void print_matrix(int *matrix);
void *multiply(void *thread_args);
	
/* Left and right operands of the computation */
int left_operand[N][N] =
{ 	
	{4, 3, 2, 1, 5},		/* Row 1 */
	{7, 8, 10, 2, 1},
	{1, 1, 0, 9, 3},
	{8, 0, 0, 5, 5},
	{10, 15, 3, 4, 1}		/* Row N */
};

int right_operand[N][N] =
{
	{2, 1, 12, 0, 0},
	{4, 5, 1, 1, 0},
	{5, 3, 7, 7, 9},
	{6, 4, 8, 4, 9},
	{0, 0, 10, 4, 2}
};

/* Mutex to access shared memory */
pthread_mutex_t mutex;

int main()
{
	/* Process-related variable */	
	int current_thread;
	/* Matrix is represented as a linear array */
	int *matrix;	
	/* Shared memory pointer */
	char *shared_mem;
	/* Shared memory identifier */
	int shared_mem_id;
	/* Each thread will be assigned an element of the result matrix */
	pthread_t threads[N * N];
	thread_arg_t thread_args[N * N];
	/* The multi-threaded application will be executed in a second process */
	pid_t child;

	/* Allocate space for matrix */
	matrix = (int *)malloc(sizeof(int) * N * N);

	/* Initialize shared memory */
	shared_mem_id = shmget(IPC_PRIVATE, sizeof(int) * N * N, IPC_CREAT | S_IRUSR | S_IWUSR);
	if(shared_mem_id == -1)
	{
		fprintf(stderr, "An error occurred while creating shared memory segment\n");
		return -1;
	}

	/* Attach shared memory segment to current process */
	shared_mem = (char *)shmat(shared_mem_id, 0, 0);
	
	/* Let's initialize the matrix from the Master thread */
	initialize_matrix(matrix);
	/* Set shared memory to initial 0 values. Notice that in shared memory the matrix is
	 * represented as a linear N*N 4-bytes vector */
	memcpy(shared_mem, matrix, sizeof(int) * N * N);

	/* Create and initialize the mutex */
	pthread_mutex_init(&mutex, NULL);

	/* Create the child process */
	child = fork();
	if(child == 0)
	{
		/* Attach shared memory segment */
		shared_mem = (char *)shmat(shared_mem_id, 0, 0);

		/* Child process creates a set of threads, one for each element in the result matrix */
		for(current_thread = 0; current_thread < N * N; current_thread++)
		{	
			thread_args[current_thread].current_thread = current_thread;
			thread_args[current_thread].shared_mem_location = shared_mem + current_thread * sizeof(int);
			pthread_create(&threads[current_thread], NULL, multiply, (void *)&thread_args[current_thread]);
		}

		/* Detach from shared memory */
		shmdt(shared_mem);
		exit(1);
	}
	else
	{
		/* Wait until child process terminated */
		waitpid(child, NULL, 0);
		
		/* Now we can read back data from the shared memory */
		memcpy((void *)matrix, (void *)shared_mem, sizeof(int) * N * N);

		/* Print the result */
		print_matrix(matrix);
	
		/* Release resources */
		shmctl(shared_mem_id, IPC_RMID, NULL);
		shmdt(shared_mem);
		free(matrix);

		return 0;
	}
}//end_main

void initialize_matrix(int *matrix)
{
	int i, j;

	/* For each row... */
	for(i = 0; i < N; i++)
	{
		/* ... and for each column... */
		for(j = 0; j < N; j++)
		{
			/* ... initialize to 0 */
			matrix[i * N + j] = 0;
		}
	}
}

void print_matrix(int *matrix)
{
	int i, j;

	/* For each row... */
	for(i = 0; i < N; i++)
	{
		/* ... and for each column... */
		for(j = 0; j < N; j++)
		{
			/* ... print matrix element */
			printf("%2d ", matrix[i * N + j]);
		}
		printf("\n");
	}
}

void *multiply(void *thread_args)
{
	int current_thread, row_L, column_L, row_R, column_R, temp;
	char *shared_mem_location;

	/* Retrieve information */
	current_thread = ((thread_arg_t *)thread_args)->current_thread;
	shared_mem_location = (char *) ((thread_arg_t *)thread_args)->shared_mem_location;

	/* Do work. This thread will calculate the element at position 'current_thread' of the linear
	 * matrix representation, and this corresponds to the element
	 *
	 *		( current_thread / N , current_thread % N )
	 *
	 * in 2D matrix. 
	 * Also, such values represent the row of the left operand and the column of the right
	 * operand that are used to calculate the multiplication. */
	row_L = current_thread / N;	
	column_R = current_thread % N;	
	row_R = 0;
	column_L = 0;
	
	/* The number of addends on the computation of a single element in the result matrix is N */
	temp = 0;
	for(; column_L < N && row_R < N; )
	{
		temp += left_operand[row_L][column_L] * right_operand[row_R][column_R];
		row_R++;
		column_L++;
	}	

	/* Save data to shared memory location */
	pthread_mutex_lock(&mutex);
	memcpy((void *)shared_mem_location, (void *)&temp, sizeof(int));
	pthread_mutex_unlock(&mutex);
}

