#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#define NUM_PHILO 8
#define T 10

int sem_id[NUM_PHILO];
int philo_pid[NUM_PHILO];

/* We must define union semun ourselves.  */
union semun {
  int val;
  struct semid_ds *buf;
  unsigned short int *array;
  struct seminfo *__buf;
};

/* Obtain a binary semaphore's ID, allocating if necessary.  */
int binary_semaphore_allocation (key_t key, int sem_flags)
{
  return semget (key, 1, sem_flags);
}

/* Deallocate a binary semaphore.  All users must have finished their
   use.  Returns -1 on failure.  */
int binary_semaphore_deallocate (int semid)
{
  union semun ignored_argument;
  return semctl (semid, 1, IPC_RMID, ignored_argument);
}

/* Initialize a binary semaphore with a value of one.  */
int binary_semaphore_initialize (int semid)
{
  union semun argument;
  unsigned short values[1];
  values[0] = 1;
  argument.array = values;
  return semctl (semid, 0, SETALL, argument);
}

/* Wait on a binary semaphore.  Block until the semaphore value is
   positive, then decrement it by one.  */

int binary_semaphore_wait (int semid)
{
  struct sembuf operations[1];
  /* Use the first (and only) semaphore.  */
  operations[0].sem_num = 0;
  /* Decrement by 1.  */
  operations[0].sem_op = -1;
  /* Permit undo'ing.  */
  operations[0].sem_flg = SEM_UNDO;
  
  return semop (semid, operations, 1);
}

/* Post to a binary semaphore: increment its value by one.  This
   returns immediately.  */

int binary_semaphore_post (int semid)
{
  struct sembuf operations[1];
  /* Use the first (and only) semaphore.  */
  operations[0].sem_num = 0;
  /* Increment by 1.  */
  operations[0].sem_op = 1;
  /* Permit undo'ing.  */
  operations[0].sem_flg = SEM_UNDO;
  
  return semop (semid, operations, 1);
}

int binary_semaphore_wait_noblock (int semid)
{
  struct sembuf operations[1];
  /* Use the first (and only) semaphore.  */
  operations[0].sem_num = 0;
  /* Decrement by 1.  */
  operations[0].sem_op = -1;
  /* To avoid to be blocked.  */
  operations[0].sem_flg = IPC_NOWAIT;
  
  return semop (semid, operations, 1);
}

void philosopher behavior(int i)
{
  int sx, dx;
  int result;
  sx = i;
  dx = ( (i+1) == 8 ) ? 0 : i+1;
  /* fork i is on the left of the philosopher, fork i+1 is on the right
     i range is 0, 8; philosopher 8 deals with 7 and 0, philosopher 0 deals with 1 and 8  */
  while(1)
  {
    /* sleep for a random time */
    sleep( srandom(1234) );
	/* try to acquire fork on the sx */
	result = binary_semaphore_wait( sem_id[sx] );
	/* if successful, try to acquire the fork on the right */
	if (result == 0)
	{
  	  result = binary_semaphore_wait_noblock( sem_id[dx] );
	  if (result != 0)
	  {
	    /* sleep for T */
	    sleep(T);
		/* retry acquiring the dx fork */
		result = binary_semaphore_wait_noblock( sem_id[dx] );
	    /* if still successful, eat */
	    if (result != 0)
	      eat();
		else
		  printf("too much time, I cannot eat!");
	    /* release forks */
	    binary_semaphore_post( sem_id[dx] );
	    binary_semaphore_post( sem_id[sx] );
	}
  }
}

int main(int argc, char** argv)
{
  /* Create forks */
  key_t key = 123;
  for (int i =0; i < NUM_PHILO; i++)
  { 
    sem_id[i] = semget(IPC_PRIVATE, 1, O_CREAT | S_IRWXU );
	binary_semaphore_initialize( sem_id[i] );
  }
  
  /* Create philosophers */
  for (int i =0; i < NUM_PHILO; i++)
  {
    philo_pid[i] = fork();
	if (philo_pid[i] == 0)
	{
      // philosopher i
	  philosopher_behavior(i);
    }
  }
}
