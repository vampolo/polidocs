#include <sys/wait.h> 
#include <unistd.h> 
#include <stdio.h> 
void char_at_a_time( char* str ) 
{ 
  while( *str!= '\0' )
  { 
    putchar( *str++ ); 
    fflush( stdout ); 
    sleep( 1 ); 
  } 
} 
main() 
{ 
  if( fork() == 0 ) 
  { 
    char_at_a_time( "............." ); 
  } 
  else 
  { 
    char_at_a_time( "|||||||||||||" ); 
  } 
}

