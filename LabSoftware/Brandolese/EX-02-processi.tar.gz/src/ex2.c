#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>

#define DEFAULT_VALUE	15

int main()
{
	int ret_value;		/* Il valore specificato di ritorno */
	pid_t pid;			/* Il PID del processo figlio */
	int status;			/* Status del processo figlio */

	printf("Immettere un valore: ");
	scanf("%d", &ret_value);

	/* Facciamo un semplice controllo, può essere utile in casi
	 * particolari, qui è solo per completezza */
	if(ret_value < 0 || ret_value > 1024)
	{
		ret_value = DEFAULT_VALUE;
	}
	
	/* Creazione del figlio */
	pid = fork();
	if(pid == 0)
	{
		printf("Il processo figlio %d ritorna subito\n", getpid());
		exit(ret_value);
	}
	else
	{
		wait(&status);
		printf("Il processo padre %d ha letto %d\n", getpid(), 
			WEXITSTATUS(status));
		
		return 0;
	}
}

