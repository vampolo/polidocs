#include <stdio.h>			/* Standard I/O */
#include <fcntl.h>			/* Funzioni di accesso ai file */
#include <unistd.h>			/* Lettura/scrittura da/su file */
#include <sys/wait.h>		/* Per sincronizzazione processi */
#include <sys/types.h>		/* Tipi di dato usati */
#include <stdlib.h>			/* Funzione exit() */
#include <signal.h>			/* Funzione kill() e annessi */
#include <string.h>			/* Funzione memset() */

/* Questo è l'handler per il figlio, SIGUSR1 è il segnale ricevuto */
void child_handler(int signal_number);

/* Questo handler è per il padre invece */
void parent_handler(int signal_number);

/* Descrittore del file in comune */
static int fd;
/* PID del figlio e del padre */
static pid_t child_pid, parent_pid;

int main()
{
	char buffer[100];			/* Buffer locale */
	char temp[] = "AAAAAAAAAA";	/* Stringa per sostituzione */
	struct sigaction child_sa,	/* Structs per la gestione del segnale utente */
		parent_sa;	
	
	/* Inizializzazione della struct per il figlio... */
	memset(&child_sa, 0, sizeof(struct sigaction));
	child_sa.sa_handler = &child_handler;

	/* e per il padre */
	memset(&parent_sa, 0, sizeof(struct sigaction));
	parent_sa.sa_handler = &parent_handler;

	fd = open("./pippo", O_RDWR);
	if(fd == -1)
	{
		/* Errore nella creazione del descrittore di file */
		fprintf(stderr, "An error occurred while opening specified file.\n");
		return 0;
	}

	/* File aperto correttamente */
	child_pid = fork();
	if(child_pid == 0)		/* CHILD */
	{
		/* Registriamo l'handler nel figlio */
		sigaction(SIGUSR1, &child_sa, NULL);
		
		/* Active spin, non molto efficiente comunque */
		while(1)
			;	
	}//end_child
	else				/* PARENT */
	{
		parent_pid = getpid();

		/* Registriamo l'handler per il padre */
		sigaction(SIGUSR1, &parent_sa, NULL);
	
		/* Leggiamo i primi 20 bytes */
		read(fd, &buffer, 20);	
		buffer[20] = '\0';
		fprintf(stdout, "Il processo padre %d ha letto %s\n", getpid(),
			buffer);
		
		/* Modifichiamo i primi 10 bytes del file */
		lseek(fd, 0, SEEK_SET);
		/* Attenzione al carattere di terminazione! */
		write(fd, temp, sizeof(temp) - 1);	
		
		/* Il processo padre invia il segnale al figlio */
		kill(child_pid, SIGUSR1);
		
		/* Ora è il padre che aspetta il segnale */
		while(1)
			;
	}//end_parent
}//end_main

void child_handler(int signal_number)
{
	char buffer[21];

	/* Legge i primi 20 byte dal file */
	lseek(fd, 0, SEEK_SET);
	read(fd, &buffer, 20);
	buffer[20] = '\0';
	fprintf(stdout, "Il processo figlio %d ha letto %s\n", 
		getpid(), buffer);
	
	/* Informa il padre della terminazione della lettura */
	kill(parent_pid, SIGUSR1);

	exit(1);
}

void parent_handler(int signal_nubmer)
{
	char buffer[11];
	int status;

	/* Leggiamo altri 10 caratteri dal file */
	read(fd, &buffer, 10);
	buffer[10] = '\0';
	fprintf(stdout, "Il processo padre %d ha letto %s\n", getpid(), 
		buffer);

	/* Legge lo stato di uscita del figlio */
	wait(&status);
	fprintf(stdout, "Il processo figlio ha terminato con %d\n", 
		WEXITSTATUS(status));

	exit(0);
}

