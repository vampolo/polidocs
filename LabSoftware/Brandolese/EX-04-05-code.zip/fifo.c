/* scrittura su una FIFO utilizzando le primitive di basso livello */
int fd = open(fifo_path, O_WRONLY);
write(fd, data, data_length);
close(fd);

/* lettura dalla FIFO usando le funzioni di alto livello */
FILE* file = fopen(fifo_path, "r");
fscanf(file, "%s", buffer);
fclose(file;)