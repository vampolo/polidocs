/*
 * Giovanni Agosta, Andrea Di Biagio
 * Politecnico di Milano, 2007
 * 
 * fetch.h
 * Formal Languages & Compilers Machine, 2007/2008
 * 
 */
#ifndef _FETCH_H
#define _FETCH_H

int fetch_execute(unsigned int *code, int pc);

#endif /* _FETCH_H */
