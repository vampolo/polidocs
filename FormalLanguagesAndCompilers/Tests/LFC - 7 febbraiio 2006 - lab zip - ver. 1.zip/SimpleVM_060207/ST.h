/***************************************************************************
                             Modulo Tabella dei Simboli
***************************************************************************/

#ifndef _ST_
#define _ST_

/*-------------------------------------------------------------------------
                         RECORD della TABELLA dei SIMBOLI
-------------------------------------------------------------------------*/
typedef struct _symrec{
  /* nome del simbolo */	
  char *name; 
  /* offset: indice del dato a livello "simplecode". Il primo simbolo
   * dichiarato avr� offset 0, il secondo offset 1, il terzo offset 2,
   * e cos� via */
  int offset; 
  int n_args; /* For functions, the number of arguments */
  int n_vars; /* For functions, the number of local variables */
  /* prossimo elemento nella lista */
  struct _symrec *next; 
}symrec;


/*========================================================================
                       Operazioni: Putsym, Getsym
========================================================================*/
/* Inserisce un simbolo in testa alla lista */
symrec *putsym(char *sym_name, int dir);

/* Insert a symbol for the given offset in the table */
symrec *putfunc(char *sym_name, int offset);

/* Dato un simbolo restituisce un puntatore alla sua "entry" nella lista.
 * Altrimenti restituisce NULL */
symrec *getsym(char *sym_name);

#endif

/************************** End Symbol Table **************************/


