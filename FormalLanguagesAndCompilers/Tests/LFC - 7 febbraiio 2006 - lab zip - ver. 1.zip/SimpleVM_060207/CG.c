#include "SM.h"
#include "CG.h"

/*=========GLOBALI======================================================*/

/* OPERAZIONI: Rappresentazione Esterna */
char *op_name[19] = {"halt", 
	             "store", 
		     "jmp_false", 
		     "goto",
		     "data", 
		     "ld_int", 
		     "ld_var",
		     "in_int", 
		     "out_int",
		     "lt", 
		     "eq", 
		     "gt", 
		     "add", 
		     "sub", 
		     "mult", 
		     "div", 
		     "pwr",
		     "call", 
		     "ret" };

/* Offset dati iniziale */
int data_offset = 0;          

/* Offset codice iniziale */
int code_offset = 0;          

/*=======================================================================*/

/* reserve_data_location ha l'unico effetto di restituire il valore di
 * data_offset e quindi di incrementarlo.
 * In altre parole, realizza un "contatore"
 */
int reserve_data_location(int dir){
  if (dir > 0)
     return data_offset++;
  else
     return data_offset--;
}

void reset_data_location(int init){
    data_offset = init;
}

int current_code_loc(){  
   return code_offset;
}

/* Riserva una locazione di codice. Vedi sopra */
int reserve_code_loc(){  
   return code_offset++;
}
                 
/* Setta alla locazione corrente (code_offest) il codice operativo
 * dato da "operation" e l'argomento dato da "arg". Si ricorda che
 * l'effetto di tale funzione � quello di scrivere, all'interno del vettore
 * "code" (si veda SM.c), i due campi della struttura "instruction" di
 * indice code_offset.
 * In piu' ha l'effetto di aggiornare il valore di code_offset.
 * */
void gen_code(code_ops operation, int arg ){ 
  setOpInstruction(code_offset, operation);
  setArgInstruction(code_offset++, arg);
}

/* Fa esattamente le stesse cose della funzione precedente, solo che le fa in
 * una locazione data (addr) */
void gen_back_code(int addr, code_ops operation, int arg){
  setOpInstruction(addr,operation);
  setArgInstruction(addr,arg);
}

void print_code(){  
   int i = 0;

   while (i < code_offset) {
      printf("%3ld: %-10s%4ld\n",i,op_name[(int) getOpInstruction(i)], getArgInstruction(i));
      i++;
   }
}

