#ifndef _BP_
#define _BP_

/*-------------------------------------------------------------------------
               The following support backpatching
-------------------------------------------------------------------------*/
 typedef struct{                   /* Etichette per i dati, if e while   */
  // "indirizzo" dell'etichetta riservata per goto
  int for_goto;  
  // "indirizzo" dell'etichetta riservata per jmp_false
  int for_jmp_false;
 } lbs;         

//N.B: "indirizzo" NON � l'indirizzo di salto, bens� � l'indice della locazione
//di codice riservata all'interno del vettore "code", che dovr� essere backpatchata.

#endif
