#include <stdlib.h>
#include <string.h>
#include "SM.h"
#include "CG.h"
#include "ST.h"

/*======GLOBALI===================================================*/

/* Probabilmente inutilizzato...Mah */
symrec *identifier; 

/* La Symbol Table (testa della lista) */
symrec *sym_table = NULL; 

/*===============================================================*/

/* Inserisce un simbolo in testa alla lista */
symrec *putsym(char *sym_name, int dir){
  symrec *ptr;
  ptr = (symrec *) malloc (sizeof(symrec));
  ptr->name = (char *) malloc (strlen(sym_name)+1);
  strcpy (ptr->name,sym_name);
  // Aggiorna l'offset, mediante reserve_data_location. In sostanza
  // associa un indice progressivo al dato che si sta aggiungendo alla
  // Symbol Table.
  // Vedere CG.[c,h]
  ptr->offset = reserve_data_location(dir);
  ptr->next = (symrec *)sym_table;
  sym_table = ptr;
  return ptr;
}

symrec *putfunc(char *sym_name, int offset){
  symrec *ptr;
  ptr = (symrec *) malloc (sizeof(symrec));
  ptr->name = (char *) malloc (strlen(sym_name)+1);
  strcpy (ptr->name,sym_name);
  ptr->offset = offset;
  ptr->next = (symrec *)sym_table;
  sym_table = ptr;
  return ptr;
}

/* Dato un simbolo restituisce un puntatore alla sua "entry" nella lista.
 * Altrimenti restituisce NULL */
symrec *getsym(char *sym_name){
  symrec *ptr;
  for (ptr = sym_table; ptr != NULL; ptr =  (symrec *)ptr->next)
    if (strcmp (ptr->name,sym_name) == 0)
      return ptr;
  return NULL;
}
