/***************************************************************************
                             Generatore di Codice 
***************************************************************************/

#ifndef _CG_
#define _CG_

/*-------------------------------------------------------------------------
                             Segmento Dati
-------------------------------------------------------------------------*/

/* Reserve a data location in the direction given by `dir' */
int reserve_data_location(int dir);

/* Set the next data location to `init' */
void reset_data_location(int init);

/*-------------------------------------------------------------------------
                             Segmento Codice
-------------------------------------------------------------------------*/


int current_code_loc();        /* Restituisce l'offset corrente           */    

int reserve_code_loc();       /* Riserva una locazinoe di codice         */

/* Genera il codice relativo alla locazione corrente */
void gen_code(code_ops operation, int arg );

/* Genera il codice in una locazione specificata */
void gen_back_code(int addr, code_ops operation, int arg  );

/*-------------------------------------------------------------------------
                           Stampa il codice a video
-------------------------------------------------------------------------*/
void print_code();

#endif

/************************** Fine del generatore di codice ****************/


