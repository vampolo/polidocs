/***************************************************************************
                             Macchina a Stack
***************************************************************************/

#ifndef _SM_
#define _SM_

/* OPERAZIONI: Rappresentazione Interna */

typedef enum { HALT, 
	       STORE, 
	       JMP_FALSE, 
	       GOTO, 
	       DATA, 
	       LD_INT, 
	       LD_VAR, 
	       READ_INT, 
	       WRITE_INT,
	       LT, 
	       EQ, 
	       GT, 
	       ADD, 
	       SUB, 
	       MULT, 
	       DIV, 
	       PWR,
	       CALL, 
	       RET } code_ops;

/* Il tipo "istruzione" � definito come un codice operativo e un argomento */
typedef struct {
  code_ops op;
  int arg;
 }instruction;

/* Ottiene il codice operativo dell'istruzione i-esima */
code_ops getOpInstruction (int i);

/* Ottiene l'argomento dell'istruzione i-esima */
int getArgInstruction (int i);

/* Scrive il codice operativo dell'istruzione i-esima */
void setOpInstruction (int i,code_ops op);

/* Scrive l'argomento dell'istruzione i-esima */
void setArgInstruction (int i, int arg);

/*=========================================================================
                             Ciclo Fetch-Execute
=========================================================================*/
void fetch_execute_cycle();

#endif
/*************************** Fine Macchina a Stack **************************/

